from flask import Flask
from flask import request
import ocrApi
import base64
from translate import Translator

app = Flask(__name__)

model = ocrApi.OcrApiObject()


@app.route('/ocr', methods=['POST'])
def get_text():
    data = request.form['data']
    img_bytes = base64.b64decode(data)
    res = model.classification(img_bytes)
    return res


@app.route('/translate', methods=['POST'])
def translate():
    source = request.form['source']
    target = request.form['target']
    data = request.form['data']
    translator = Translator(from_lang=source, to_lang=target)
    translation = translator.translate(data)
    return translation


if __name__ == '__main__':
    app.run(host='0.0.0.0', debug=True)
