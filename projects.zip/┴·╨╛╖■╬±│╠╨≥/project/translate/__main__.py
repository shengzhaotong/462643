#!/usr/bin/env python
# encoding: utf-8

from .main import main

main()
