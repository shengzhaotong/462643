class InvalidProviderError(Exception):
    pass

class TranslationError(Exception):
    pass