package loongsonTest;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static org.apache.commons.codec.binary.Base64.encodeBase64;

public class Demo01 {

    public static void main(String[] args) throws Exception {
        String imgFile = "test.png";
        String imgBase64 = "";
        File file = new File(imgFile);
        byte[] content = new byte[(int) file.length()];
        FileInputStream finputstream = new FileInputStream(file);
        finputstream.read(content);
        finputstream.close();
        imgBase64 = new String(encodeBase64(content));
        String finalImgBase6 = imgBase64;
        String text = getText(finalImgBase6);
        System.out.println(text);
    }

    public static String getText (String data) {
        CloseableHttpClient httpClient = null;
        String result = null;
        try {
            httpClient = HttpClients.createDefault();
            List<NameValuePair> params = new ArrayList<NameValuePair>();
            params.add(new BasicNameValuePair("data", data));
            HttpPost httpPost = new HttpPost("http://47.97.23.194:5000/ocr");
            httpPost.addHeader("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
            httpPost.setEntity(new UrlEncodedFormEntity(params, "utf-8"));
            HttpResponse execute = httpClient.execute(httpPost);
            // 获取状态码
            int statusCode = execute.getStatusLine().getStatusCode();
            // 获取结果
            HttpEntity entity = execute.getEntity();
            result = EntityUtils.toString(entity, "utf-8");
        } catch (IOException e) {
            System.err.println(e.getMessage());
        } finally {
            if (httpClient != null) {
                try {
                    httpClient.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return result;
    }

}
