package loongsonTest;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;


public class Demo10 {

    public static void main(String[] args) {
        String res1 = getRes("chinese", "english", "这是一台电脑");
        String res2 = getRes("english", "chinese", "This is one computer!");
        System.out.println("res1 : "+res1);
        System.out.println("res2 : "+res2);
    }

    public static String getRes (String source, String target, String data) {
        CloseableHttpClient httpClient = null;
        String result = null;
        try {
            httpClient = HttpClients.createDefault();
            List<NameValuePair> params = new ArrayList<NameValuePair>();
            params.add(new BasicNameValuePair("source", source));
            params.add(new BasicNameValuePair("target", target));
            params.add(new BasicNameValuePair("data", data));
            HttpPost httpPost = new HttpPost("http://47.97.23.194:5000/translate");
            httpPost.addHeader("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
            httpPost.setEntity(new UrlEncodedFormEntity(params, "utf-8"));
            HttpResponse execute = httpClient.execute(httpPost);
            // 获取状态码
            int statusCode = execute.getStatusLine().getStatusCode();
            // 获取结果
            HttpEntity entity = execute.getEntity();
            result = EntityUtils.toString(entity, "utf-8");
        } catch (IOException e) {
            System.err.println(e.getMessage());
        } finally {
            if (httpClient != null) {
                try {
                    httpClient.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return result;
    }

}
